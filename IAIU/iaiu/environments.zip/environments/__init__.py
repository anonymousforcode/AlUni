from iaiu.environments.base_env import Env as Environment
import iaiu.environments.dmc_env
import iaiu.environments.robot_env
